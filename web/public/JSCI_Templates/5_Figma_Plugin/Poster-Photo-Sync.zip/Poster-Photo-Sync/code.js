// Poster Photo Sync
// Select one or more poster frames, then run. The photo in the main photo layer
// (Photo-REPLACE-ME, Photo-Landscape-REPLACE-ME or Photo-Portrait-REPLACE-ME)
// is copied into the background layers (BG-Photo-REPLACE-ME and Photo-Backdrop-REPLACE-ME),
// which stay soft and see-through behind the poster.

const MAIN = /^Photo(-Landscape|-Portrait)?-REPLACE-ME$/;
const BG = /^BG-Photo-REPLACE-ME$/;
const BACKDROP = /^Photo-Backdrop-REPLACE-ME$/;

function imageOf(node) {
  if (!("fills" in node) || node.fills === figma.mixed) return null;
  for (const p of node.fills) if (p.type === "IMAGE" && p.imageHash) return p;
  return null;
}

function apply(target, img, opacity, blur) {
  target.fills = [{ type: "IMAGE", imageHash: img.imageHash, scaleMode: "FILL", visible: true, opacity: 1 }];
  target.opacity = opacity;
  const others = ("effects" in target ? target.effects : []).filter(e => e.type !== "LAYER_BLUR");
  target.effects = others.concat([{ type: "LAYER_BLUR", radius: blur, visible: true }]);
}

let done = 0, missing = 0;
const sel = figma.currentPage.selection;
if (!sel.length) {
  figma.closePlugin("Select the poster frame first, then run Poster Photo Sync.");
} else {
  for (const root of sel) {
    const scope = "findOne" in root ? root : null;
    if (!scope) continue;
    const main = scope.findOne(n => MAIN.test(n.name) && imageOf(n));
    if (!main) { missing++; continue; }
    const img = imageOf(main);
    for (const n of scope.findAll(n => BG.test(n.name) && "fills" in n)) { apply(n, img, 0.45, 28); done++; }
    for (const n of scope.findAll(n => BACKDROP.test(n.name) && "fills" in n)) { apply(n, img, 0.7, 40); done++; }
  }
  if (done) figma.closePlugin(`Background updated with your photo (${done} layer${done > 1 ? "s" : ""}).`);
  else figma.closePlugin(missing ? "No photo found. Put your image in the Photo-…-REPLACE-ME layer first." : "No background photo layers found in the selection.");
}
